<?PHP include ('config.php');
//lengkapkan aturcara ini
header("location:index.php");
?>




