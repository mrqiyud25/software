<!--Membuat sambungan ke db-->
<?php
 $connect=mysqli_connect('localhost:3306','', '', '') or die('gagal disambung ke db');
?>

